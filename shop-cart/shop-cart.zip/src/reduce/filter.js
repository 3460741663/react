const filter = 'all';

function filterReducer() {
  return filter;
}
export default filterReducer;